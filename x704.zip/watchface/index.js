﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */


	//*******************************//
	//*								*//
	//*		X704 Sport GTR4  		*//
	//*		2023 © leXxiR 4pda		*//
	//*								*//
	//*******************************//
	

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_temperature_current_text_img = ''
		let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
		let normal_city_name_text = ''
		let normal_system_disconnect_img = ''
		let normal_system_clock_img = ''

        //dynamic modify end

        let bezel = ''
		let bezel_under = ''
        let bezelIndex = 0;
		let bezelNum = 8;
		let dots = ''
		let dotsVisible = false;
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
		let normal_heart_jumpable_img_click = ''
		let normal_alarm_jumpable_img_click = ''
		let steps_text = ''
		
		let delay_Timer = null;
		let clicks = 0;
		let clicksDelay = 350;
		let changeColorEnabled = true;		
		
		var curAODmode;
		let AODmodes = ["пустой", "часы", "часы, дата и шаги"];
		let AODmodeName;
		
		let tapsScreen = ''
		let settingsScreen = ''
		let settings_btn;
		let longPress_Timer = null;
		let longPressDelay = 900;
		let checkBT;
		let switch_checkBT;
		let switch_hourlyVibro;
		let switch_changeColor;
		let switch_randomColor;
		let everyHourVibro = false;
		let randomColor = false;
		

		let curTime = hmSensor.createSensor(hmSensor.id.TIME);
		const step = hmSensor.createSensor(hmSensor.id.STEP);

	//------------------------ автозамена иконок погоды -----------------------------------

		let weather_icons = ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_0n.png","w_1n.png","w_3n.png"]

		let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
		let weatherData = weather.getForecastWeather();
		let forecastData = weatherData.forecastData;
		let sunData = weatherData.tideData;
		let today = '';
		let sunriseMins = '';
		let sunsetMins = '';
		let sunriseMins_def = 8 * 60;			// время восхода
		let sunsetMins_def = 20 * 60;			// и заката по умолчанию

		let curMins = '';
		
		let isDayIcons = true;
		let wiReplacement = [0, 1, 2, 3, 5, 14];		// индексы иконок для замены день-ночь
		
		function autoToggleWeatherIcons() {

			weatherData = weather.getForecastWeather();
			sunData = weatherData.tideData;
			if (sunData.count > 0){
				today = sunData.data[0];
				sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
				sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
			} else {
				sunriseMins = sunriseMins_def;
				sunsetMins = sunsetMins_def;
			}

			curMins = curTime.hour * 60 + curTime.minute;
			let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
			
			if(isDayNow){
				if(!isDayIcons){
					for (let i = 0; i < wiReplacement.length; i++) {
					  weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + ".png";
					}
					isDayIcons = true;
				}
			} else {
				if(isDayIcons){
					for (let i = 0; i < wiReplacement.length; i++) {
					  weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + "n.png";
					}
					isDayIcons = false;
				}
			}
		}

	//------------------------ автозамена иконок погоды ----------------------------------- \\	




		let second_circle_scale = ''
		let halfsec_Timer = null;
		let sc_increase = true;

		function showDots() {
			dotsVisible = !dotsVisible;
			dots.setProperty(hmUI.prop.VISIBLE, dotsVisible);
			let isAOD = (hmSetting.getScreenType() == hmSetting.screen_type.AOD);
			if (!isAOD && !dotsVisible) updateSeconds();
		}
		
        function setSecondsAnim(on) {		

			if (on){
				if (halfsec_Timer) timer.stopTimer(halfsec_Timer);
				halfsec_Timer = timer.createTimer(0, 500, showDots, {});
			} else {
				if (halfsec_Timer) timer.stopTimer(halfsec_Timer);
				halfsec_Timer = null;
				dots.setProperty(hmUI.prop.VISIBLE, false);
			}
        }
		
		let bg_fill = '';
		let bgColor = [0xffee00, 0xffb700, 0x97a977, 0xa6bdb5, 0x00c2ff, 0x8c8c8c, 0xffffff, 0xa99077, 0xbe5cf9, 0x00ffb7, 0x5a5858, 0xa97777, 0x77a9a3, 0x7977a9];
		let colorIndex = 0;

		let text_fill = [];
		let textColor = [0xffee00, 0x93e425, 0xff7a03, 0xeb212d, 0x3a6afc, 0x45b77b, 0xffffff, 0x8f9090, 0x00c2ff, 0x00ffb7];
		let textColorIndex = 0;
		
		let bezelUnderColor = [0x9c910e, 0x649023, 0x9c5110, 0x912027, 0x283974, 0x367252, 0x9c9a9a, 0x5e5d5d];
		

		function updateSeconds() {
		  let angle = curTime.second * 6 - 87;
		  if (curTime.second == 0) angle = 273;
		  if (curTime.second == 1) sc_increase = !sc_increase;
		  
		  let prop = {
			  'start_angle': -87,
			  'end_angle': 273,
		  }

		  if (sc_increase) prop['end_angle'] = angle;
		  else prop['start_angle'] = angle;
		  second_circle_scale.setProperty(hmUI.prop.MORE, prop);
		}
		
		
        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
        let stopVibro_Timer = null;
		
		function vibro(scene = 25) {
			let stopDelay = 50;
			vibrate.stop();
			vibrate.scene = scene;
			if(scene < 23 || scene > 25) stopDelay = 1220;
			vibrate.start();
			stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
        }		

		function stopVibro(){
			vibrate.stop();
			timer.stopTimer(stopVibro_Timer);
		}

		function randomInt(min, max) {
		  let rand = min + Math.random() * (max + 1 - min);
		  return Math.floor(rand);
		}

		function setRandomColors() {		// случайные цвета
			colorIndex = randomInt(0, bgColor.length - 1);
			bezelIndex = randomInt(0, bezelNum - 1);
			textColorIndex = randomInt(0, textColor.length - 1);
			setBgColor(colorIndex);
			setBezel(bezelIndex);
			fillTextColor(textColor[textColorIndex]);
			setClockColor(textColorIndex);
		}

		function setBgColor(index) {
			bg_fill.setProperty(hmUI.prop.MORE, { 
				x: 20,
				y: 20,
				w: 426,
				h: 426,
				radius: 203,
				color: bgColor[index],
			});
		}

		function changeColor() {
			vibro();
			if (changeColorEnabled) {
				colorIndex = (colorIndex + 1) % bgColor.length;
				setBgColor(colorIndex);
				hmFS.SysProSetInt('X704_colorIndex', colorIndex);
			}
			else hmUI.showToast({text: "Смена цвета отключена!"});
		}

		function setBezel(index) {
            bezel_under.setProperty(hmUI.prop.MORE, { 
			  x: 0,
			  y: 0,
			  w: 466,
			  h: 466,
			  radius: 233,
			  color: bezelUnderColor[index],
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});			
            bezel.setProperty(hmUI.prop.MORE, { 
              src: `bezel_${index}.png`,
            });
		}

		function toggleBezel() {
			bezelIndex = (bezelIndex + 1) % bezelNum;
            setBezel(bezelIndex);
			hmFS.SysProSetInt('X704_bezelIndex', bezelIndex);
		}


		function changeTextColor() {
			vibro();
			if (changeColorEnabled) {
				textColorIndex = (textColorIndex + 1) % textColor.length;
				fillTextColor(textColor[textColorIndex]);
				setClockColor(textColorIndex);
				hmFS.SysProSetInt('X704_textColorIndex', textColorIndex);
			}
			else hmUI.showToast({text: "Смена цвета отключена!"});
		}

		function setClockColor(index) {
			normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_system_clock_img.setProperty(hmUI.prop.MORE, {
              x: 220,
              y: 145,
              src: `status_clock_${index}.png`,
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		}


		function fillTextColor(color) {
			text_fill[0].setProperty(hmUI.prop.MORE, { 
			  x: 70,
			  y: 172,
			  w: 326,
			  h: 75,
			  color: color,
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			text_fill[1].setProperty(hmUI.prop.MORE, { 
			  x: 190,
			  y: 385,
			  w: 87,
			  h: 30,
			  color: color,
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			text_fill[2].setProperty(hmUI.prop.MORE, { 
			  x: 190,
			  y: 48,
			  w: 87,
			  h: 68,
			  color: color,
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
		
			steps_text.setProperty(hmUI.prop.MORE, { color: color});
			normal_city_name_text.setProperty(hmUI.prop.MORE, { color: color});
		}


		function updateCityName(){
			weatherData = weather.getForecastWeather();
			normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);
		}
		

		function updateSteps(){
			let value = step.current.toString();
			steps_text.setProperty(hmUI.prop.TEXT, value);
		}


		function checkClicks() {		
			switch(clicks) {
			   case 2:
					if (changeColorEnabled)	{
						toggleBezel();
						fillTextColor(textColor[bezelIndex]);
						setClockColor(bezelIndex);
						hmFS.SysProSetInt('X704_textColorIndex', bezelIndex);
					} else hmUI.showToast({text: "Смена цвета отключена!"});
				break;
			   default:
					if (changeColorEnabled)	toggleBezel();
					else hmUI.showToast({text: "Смена цвета отключена!"});
				break;
			}

			timer.stopTimer(delay_Timer);
			clicks = 0;
        }

        function getClick() {
			clicks++;
			if(delay_Timer) timer.stopTimer(delay_Timer);
			delay_Timer = timer.createTimer(clicksDelay, 0, checkClicks, {});
			vibro();
        }

		function toggleСhangeColorEnable() {
			changeColorEnabled = !changeColorEnabled;
			hmFS.SysProSetBool('X704_changeColorEnabled', changeColorEnabled);
			vibro();
			switch_changeColor.setProperty(hmUI.prop.SRC, changeColorEnabled ? 'slider_on.png' : 'slider_off.png'); 

        }


		let apps = [['Нет действия', '-'], ['Таймер', 'CountdownAppScreen'], ['Секундомер', 'StopWatchScreen'], ['Мировые часы', 'WorldClockScreen'], ['Сон', 'Sleep_HomeScreen'], ['Стресс', 'StressHomeScreen'], ['SP02 (Кислород)', 'spo_HomeScreen'], ['Дыхание', 'RespirationsettingScreen'], ['Найти телефон', 'FindPhoneScreen'], ['Музыка', 'PhoneMusicCtrlScreen']];
		let tapH = 3;
		let tapM = 2;
		let tapH_appName = ''
		let tapM_appName = ''

		function showAppScreen(index) {
			if (index){
				vibro();
				hmApp.startApp({ url: apps[index][1], native: true });
			}
		}


	//--------------------- контроль потери связи  ---------------------
		
		function checkConnection(check = true) {
			hmBle.removeListener;
			if (check){
				hmBle.addListener(function (status) {
					if(!status && checkBT) {
						hmUI.showToast({text: "Нет связи!!!"});
						vibro(9);
					}
					if(status && checkBT) {
						hmUI.showToast({text: "Снова на связи!"});
						vibro(0);
					}
				})			
			} 
		}

		function toggleСheckConnection() {
			checkBT = !checkBT;
			hmFS.SysProSetBool('nsw_checkBT', checkBT);
			vibro();		// вибрация при смене
			checkConnection(checkBT);
			switch_checkBT.setProperty(hmUI.prop.SRC, checkBT ? 'slider_on.png' : 'slider_off.png'); 
        }

	//--------------------------------------------------------------- \\

		function toggleEveryHourVibro() {
			everyHourVibro = !everyHourVibro;
			hmFS.SysProSetBool('nsw_hourlyVibro', everyHourVibro);
			vibro();		// вибрация при смене
			//hourlyVibro_img.setProperty(hmUI.prop.VISIBLE, everyHourVibro);
			switch_hourlyVibro.setProperty(hmUI.prop.SRC, everyHourVibro ? 'slider_on.png' : 'slider_off.png'); 

        }

		function setEveryHourVibro() {
			curTime.addEventListener(curTime.event.MINUTEEND, function () {
					if (everyHourVibro && !(curTime.minute % 60)) vibro(27);
			});

        }

		function toggleRandomColor() {
			randomColor = !randomColor;
			hmFS.SysProSetBool('X704_randomColor', randomColor);
			vibro();
			switch_randomColor.setProperty(hmUI.prop.SRC, randomColor ? 'slider_on.png' : 'slider_off.png');
			if (!randomColor) {
				hmFS.SysProSetInt('X704_colorIndex', colorIndex);
				hmFS.SysProSetInt('X704_bezelIndex', bezelIndex);
				hmFS.SysProSetInt('X704_textColorIndex', textColorIndex);
			}
        }

	// ---------------------------- загрузка настроек ----------------------------
		function loadSettings() {
			if (hmFS.SysProGetInt('X704_aod') === undefined) {
				curAODmode = 2;
				hmFS.SysProSetInt('X704_aod', curAODmode);
			} else {
				curAODmode = hmFS.SysProGetInt('X704_aod');
			}
			
			if (hmFS.SysProGetBool('nsw_checkBT') === undefined) {
				checkBT = false;
				hmFS.SysProSetBool('nsw_checkBT', checkBT);
			} else {
				checkBT = hmFS.SysProGetBool('nsw_checkBT');
			}
			
			if (hmFS.SysProGetBool('nsw_hourlyVibro') === undefined) {
				everyHourVibro = false;
				hmFS.SysProSetBool('nsw_hourlyVibro', everyHourVibro);
			} else {
				everyHourVibro = hmFS.SysProGetBool('nsw_hourlyVibro');
			}
			
			if (!randomColor) {
				if (hmFS.SysProGetInt('X704_colorIndex') === undefined) {
					colorIndex = 0;
					hmFS.SysProSetInt('X704_colorIndex', colorIndex);
				} else {
					colorIndex = hmFS.SysProGetInt('X704_colorIndex');
				}

				if (hmFS.SysProGetInt('X704_bezelIndex') === undefined) {
					bezelIndex = 0;
					hmFS.SysProSetInt('X704_bezelIndex', bezelIndex);
				} else {
					bezelIndex = hmFS.SysProGetInt('X704_bezelIndex');
				}

				if (hmFS.SysProGetInt('X704_textColorIndex') === undefined) {
					textColorIndex = 0;
					hmFS.SysProSetInt('X704_textColorIndex', textColorIndex);
				} else {
					textColorIndex = hmFS.SysProGetInt('X704_textColorIndex');
				}
			}
			
			if (hmFS.SysProGetBool('X704_changeColorEnabled') === undefined) {
				changeColorEnabled = true;
				hmFS.SysProSetBool('X704_changeColorEnabled', changeColorEnabled);
			} else {
				changeColorEnabled = hmFS.SysProGetBool('X704_changeColorEnabled');
			}

			if (hmFS.SysProGetBool('X704_randomColor') === undefined) {
				randomColor = false;
				hmFS.SysProSetBool('X704_randomColor', randomColor);
			} else {
				randomColor = hmFS.SysProGetBool('X704_randomColor');
			}

			if (hmFS.SysProGetInt('X704_tapH') === undefined) {
				tapH = 1;
				hmFS.SysProSetInt('X704_tapH', tapH);
			} else {
				tapH = hmFS.SysProGetInt('X704_tapH');
			}

			if (hmFS.SysProGetInt('X704_tapM') === undefined) {
				tapM = 2;
				hmFS.SysProSetInt('X704_tapM', tapM);
			} else {
				tapM = hmFS.SysProGetInt('X704_tapM');
			}
			
		}


// ---------------------------- экран настроек ----------------------------


		function toggleAODmode() {
			curAODmode = (curAODmode + 1) % AODmodes.length;
			hmFS.SysProSetInt('X704_aod', curAODmode);
			vibro();		// вибрация при смене
			AODmodeName.setProperty(hmUI.prop.TEXT, AODmodes[curAODmode]);
        }

	
		function createSettingsScreen() {

			settingsScreen = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
            });
			settingsScreen.setProperty(hmUI.prop.VISIBLE, false);

            settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_fill.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 0,
				y: 20,
				w: 466,
				h: 64,
				text_size: 30,
				text: "X закрыть",
				color: '0xFFFFCE9B',
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V
			}).addEventListener(hmUI.event.CLICK_UP, function () {
					vibro();
					showSettingsScreen(false);
			});
			
			settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 0,
				y: 60,
				w: 466,
				h: 64,
				text_size: 36,
				text: "НАСТРОЙКИ",
				color: '0xFFFFFFFF',
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V
			});

 			settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 70,
				y: 115,
				w: 320,
				h: 64,
				text_size: 32,
				text: "Режим AOD:",
				color: '0xFFFFFFCC',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});

			AODmodeName = settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 150,
				y: 155,
				w: 320,
				h: 64,
				text_size: 32,
				text: AODmodes[curAODmode],
				color: '0xFFFFFFFF',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});
			
			settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 145,
              y: 115,
              w: 340,
              h: 115,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }).addEventListener(hmUI.event.CLICK_UP, function () {
					toggleAODmode();
			});

            switch_checkBT = settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 220,
              w: 60,
              h: 33,
              src: checkBT ? 'slider_on.png' : 'slider_off.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 130,
				y: 205,
				w: 320,
				h: 64,
				text_size: 32,
				text: "Вибрация при потере связи",
				color: '0xFFFFFFCC',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});

			settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 210,
              w: 360,
              h: 60,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }).addEventListener(hmUI.event.CLICK_UP, function () {
					toggleСheckConnection();
			});


            switch_hourlyVibro = settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 280,
              w: 60,
              h: 33,
              src: everyHourVibro ? 'slider_on.png' : 'slider_off.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 130,
				y: 265,
				w: 320,
				h: 64,
				text_size: 32,
				text: "Вибрация в начале часа",
				color: '0xFFFFFFCC',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});

			settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 270,
              w: 360,
              h: 60,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }).addEventListener(hmUI.event.CLICK_UP, function () {
					toggleEveryHourVibro();
			});

            switch_randomColor = settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 340,
              w: 60,
              h: 33,
              src: randomColor ? 'slider_on.png' : 'slider_off.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 130,
				y: 325,
				w: 320,
				h: 64,
				text_size: 32,
				text: "Случайный цвет циферблата",
				color: '0xFFFFFFCC',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});

			settingsScreen.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 330,
              w: 360,
              h: 60,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }).addEventListener(hmUI.event.CLICK_UP, function () {
					toggleRandomColor();
			});

 			settingsScreen.createWidget(hmUI.widget.TEXT, {
				x: 0,
				y: 390,
				w: 466,
				h: 64,
				text_size: 32,
				text: "Тап-зоны >>",
				color: '0xFFFFFFCC',
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V
			}).addEventListener(hmUI.event.CLICK_UP, function () {
					vibro();
					showSettingsScreen(false);
					showTapsScreen();
			});

		}

		function showSettingsScreen(value = true) {
			settingsScreen.setProperty(hmUI.prop.VISIBLE, value);
		}

		function openSettingsScreen() {
			if(longPress_Timer) timer.stopTimer(longPress_Timer);
			vibro();
			showSettingsScreen();
		}

// ---------------------------- экран настроек тап-зон ---------------------------- \\


		function createTapsScreen() {

			tapsScreen = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
            });
			tapsScreen.setProperty(hmUI.prop.VISIBLE, false);

            tapsScreen.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_fill.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			tapsScreen.createWidget(hmUI.widget.TEXT, {
				x: 0,
				y: 20,
				w: 466,
				h: 64,
				text_size: 30,
				text: "X закрыть",
				color: '0xFFFFCE9B',
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V
			}).addEventListener(hmUI.event.CLICK_UP, function () {
					vibro();
					showTapsScreen(false);
			});
			
			tapsScreen.createWidget(hmUI.widget.TEXT, {
				x: 0,
				y: 60,
				w: 466,
				h: 64,
				text_size: 36,
				text: "НАСТРОЙКА",
				color: '0xFFFFFFFF',
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V
			});

			tapsScreen.createWidget(hmUI.widget.TEXT, {
				x: 0,
				y: 100,
				w: 466,
				h: 64,
				text_size: 36,
				text: "ТАП-ЗОН",
				color: '0xFFFFFFFF',
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V
			});			
			
			tapsScreen.createWidget(hmUI.widget.TEXT, {
				x: 70,
				y: 150,
				w: 320,
				h: 64,
				text_size: 32,
				text: "Зона ЧАСЫ",
				color: '0xFFFFFFCC',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});

			tapH_appName = tapsScreen.createWidget(hmUI.widget.TEXT, {
				x: 140,
				y: 195,
				w: 320,
				h: 64,
				text_size: 32,
				text: apps[tapH][0],
				color: '0xFFFFFFFF',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});

			tapsScreen.createWidget(hmUI.widget.IMG, {
              x: 70,
              y: 150,
              w: 340,
              h: 150,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }).addEventListener(hmUI.event.CLICK_UP, function () {
				toggleTapAppH();
			});

			tapsScreen.createWidget(hmUI.widget.TEXT, {
				x: 70,
				y: 250,
				w: 320,
				h: 64,
				text_size: 32,
				text: "Зона МИНУТЫ",
				color: '0xFFFFFFCC',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});

			tapM_appName = tapsScreen.createWidget(hmUI.widget.TEXT, {
				x: 140,
				y: 295,
				w: 320,
				h: 64,
				text_size: 32,
				text: apps[tapM][0],
				color: '0xFFFFFFFF',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});
			
			tapsScreen.createWidget(hmUI.widget.IMG, {
              x: 70,
              y: 250,
              w: 340,
              h: 150,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }).addEventListener(hmUI.event.CLICK_UP, function () {
				toggleTapAppM();
			});
			
            switch_changeColor = tapsScreen.createWidget(hmUI.widget.IMG, {
              x: 75,
              y: 375,
              w: 60,
              h: 33,
              src: changeColorEnabled ? 'slider_on.png' : 'slider_off.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			tapsScreen.createWidget(hmUI.widget.TEXT, {
				x: 140,
				y: 360,
				w: 320,
				h: 64,
				text_size: 32,
				text: "Смена цвета по нажатию",
				color: '0xFFFFFFCC',
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V
			});

			tapsScreen.createWidget(hmUI.widget.IMG, {
              x: 70,
              y: 375,
              w: 380,
              h: 80,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }).addEventListener(hmUI.event.CLICK_UP, function () {
					toggleСhangeColorEnable();
			});
			
		}

		function showTapsScreen(value = true) {
			tapsScreen.setProperty(hmUI.prop.VISIBLE, value);
		}

		function toggleTapAppH() {
			tapH = (tapH + 1) % apps.length;
			if (tapH && tapH == tapM) tapH = (tapH + 1) % apps.length;
			vibro();		// вибрация при смене
			tapH_appName.setProperty(hmUI.prop.TEXT, apps[tapH][0]);
			hmFS.SysProSetInt('X704_tapH', tapH);
		}

		function toggleTapAppM() {
			tapM = (tapM + 1) % apps.length;
			if (tapM && tapM == tapH) tapM = (tapM + 1) % apps.length;
			vibro();		// вибрация при смене
			tapM_appName.setProperty(hmUI.prop.TEXT, apps[tapM][0]);
			hmFS.SysProSetInt('X704_tapM', tapM);
		}

// ---------------------------- экран настроек тап-зон ---------------------------- \\


// ---------------------------- AOD ----------------------------

		function makeAOD() {
			
			let mode = hmFS.SysProGetInt('X704_aod');
			
			bg_fill = hmUI.createWidget(hmUI.widget.FILL_RECT, {
			  x: 0,
			  y: 0,
			  w: 466,
			  h: 466,
			  radius: 233,
			  color: '0xFF000000',
			  show_level: hmUI.show_level.ONLY_AOD,
			});

			if (mode == 1){			// часы
			
				bg_fill.setProperty(hmUI.prop.MORE, { 
					x: 0,
					y: 0,
					w: 466,
					h: 466,
					radius: 233,
					color: 0x001f17, 
				});

				text_fill[0] = hmUI.createWidget(hmUI.widget.FILL_RECT, {
				  x: 70,
				  y: 172,
				  w: 326,
				  h: 75,
				  color: 0x00ffb7,
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				hmUI.createWidget(hmUI.widget.IMG, {
				  x: 0,
				  y: 0,
				  src: 'bg_aod.png',
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				hmUI.createWidget(hmUI.widget.IMG_STATUS, {
				  x: 74,
				  y: 239,
				  src: 'status_bt_aod.png',
				  type: hmUI.system_status.DISCONNECT,
				  show_level: hmUI.show_level.ONLY_AOD,
				});


				hmUI.createWidget(hmUI.widget.IMG_TIME, {
				  hour_startX: 73,
				  hour_startY: 177,
				  hour_array: ["digAOD_0.png","digAOD_1.png","digAOD_2.png","digAOD_3.png","digAOD_4.png","digAOD_5.png","digAOD_6.png","digAOD_7.png","digAOD_8.png","digAOD_9.png"],
				  hour_zero: 1,
				  hour_space: 6,
				  hour_align: hmUI.align.LEFT,

				  minute_startX: 253,
				  minute_startY: 177,
				  minute_array: ["digAOD_0.png","digAOD_1.png","digAOD_2.png","digAOD_3.png","digAOD_4.png","digAOD_5.png","digAOD_6.png","digAOD_7.png","digAOD_8.png","digAOD_9.png"],
				  minute_zero: 1,
				  minute_space: 6,
				  minute_follow: 0,
				  minute_align: hmUI.align.LEFT,

				  show_level: hmUI.show_level.ONLY_AOD,
				});

				dots = hmUI.createWidget(hmUI.widget.IMG, {
				  x: 226,
				  y: 192,
				  src: 'dots.png',
				  show_level: hmUI.show_level.ONLY_AOD,
				});
				
			}

			if (mode == 2){			// обычный
			
				bg_fill.setProperty(hmUI.prop.MORE, { 
					x: 0,
					y: 0,
					w: 466,
					h: 466,
					radius: 233,
					color: 0x001f17, 
				});

				text_fill[0] = hmUI.createWidget(hmUI.widget.FILL_RECT, {
				  x: 70,
				  y: 172,
				  w: 326,
				  h: 75,
				  color: 0x00ffb7,
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				text_fill[1] = hmUI.createWidget(hmUI.widget.FILL_RECT, {
				  x: 190,
				  y: 385,
				  w: 87,
				  h: 30,
				  color: 0x00ffb7,
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				text_fill[2] = hmUI.createWidget(hmUI.widget.FILL_RECT, {
				  x: 190,
				  y: 48,
				  w: 87,
				  h: 68,
				  color: 0x00ffb7,
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				hmUI.createWidget(hmUI.widget.IMG, {
				  x: 0,
				  y: 0,
				  src: 'bg_aod.png',
				  show_level: hmUI.show_level.ONLY_AOD,
				});


				hmUI.createWidget(hmUI.widget.IMG_STATUS, {
				  x: 220,
				  y: 147,
				  src: 'status_clock_aod.png',
				  type: hmUI.system_status.CLOCK,
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				hmUI.createWidget(hmUI.widget.TEXT, {
				  x: 84,
				  y: 233,
				  w: 300,
				  h: 30,
				  text_size: 22,
				  char_space: 0,
				  line_space: 0,
				  color: 0x01be89,
				  text: weatherData.cityName,
				  align_h: hmUI.align.CENTER_H,
				  align_v: hmUI.align.TOP,
				  text_style: hmUI.text_style.NONE,
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				hmUI.createWidget(hmUI.widget.IMG_STATUS, {
				  x: 74,
				  y: 239,
				  src: 'status_bt_aod.png',
				  type: hmUI.system_status.DISCONNECT,
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				hmUI.createWidget(hmUI.widget.IMG_DATE, {
				  day_startX: 192,
				  day_startY: 77,
				  day_sc_array: ["digDateAOD_0.png","digDateAOD_1.png","digDateAOD_2.png","digDateAOD_3.png","digDateAOD_4.png","digDateAOD_5.png","digDateAOD_6.png","digDateAOD_7.png","digDateAOD_8.png","digDateAOD_9.png"],
				  day_tc_array: ["digDateAOD_0.png","digDateAOD_1.png","digDateAOD_2.png","digDateAOD_3.png","digDateAOD_4.png","digDateAOD_5.png","digDateAOD_6.png","digDateAOD_7.png","digDateAOD_8.png","digDateAOD_9.png"],
				  day_en_array: ["digDateAOD_0.png","digDateAOD_1.png","digDateAOD_2.png","digDateAOD_3.png","digDateAOD_4.png","digDateAOD_5.png","digDateAOD_6.png","digDateAOD_7.png","digDateAOD_8.png","digDateAOD_9.png"],
				  day_zero: 1,
				  day_space: -1,
				  day_align: hmUI.align.LEFT,
				  day_is_character: false,
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				steps_text = hmUI.createWidget(hmUI.widget.TEXT, {
				  x: 0,
				  y: 331,
				  w: 466,
				  h: 50,
				  text_size: 50,
				  char_space: 0,
				  line_space: 0,
				  color: 0x00ffb7,
				  align_h: hmUI.align.CENTER_H,
				  align_v: hmUI.align.CENTER_V,
				  text_style: hmUI.text_style.NONE,
				  show_level: hmUI.show_level.ONLY_AOD,
				});

				step.addEventListener(hmSensor.event.CHANGE, function() {
				  updateSteps();
				});

				hmUI.createWidget(hmUI.widget.IMG_TIME, {
				  hour_startX: 73,
				  hour_startY: 177,
				  hour_array: ["digAOD_0.png","digAOD_1.png","digAOD_2.png","digAOD_3.png","digAOD_4.png","digAOD_5.png","digAOD_6.png","digAOD_7.png","digAOD_8.png","digAOD_9.png"],
				  hour_zero: 1,
				  hour_space: 6,
				  hour_align: hmUI.align.LEFT,

				  minute_startX: 253,
				  minute_startY: 177,
				  minute_array: ["digAOD_0.png","digAOD_1.png","digAOD_2.png","digAOD_3.png","digAOD_4.png","digAOD_5.png","digAOD_6.png","digAOD_7.png","digAOD_8.png","digAOD_9.png"],
				  minute_zero: 1,
				  minute_space: 6,
				  minute_follow: 0,
				  minute_align: hmUI.align.LEFT,

				  show_level: hmUI.show_level.ONLY_AOD,
				});

				dots = hmUI.createWidget(hmUI.widget.IMG, {
				  x: 226,
				  y: 192,
				  src: 'dots.png',
				  show_level: hmUI.show_level.ONLY_AOD,
				});
				
			}			
/*
			hmUI.createWidget(hmUI.widget.IMG, {
			  x: 0,
			  y: 0,
			  w: 466,
			  h: 466,
			  src: 'bg_fill_20.png',
			  show_level: hmUI.show_level.ONLY_AOD,
			});		
*/

			const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
				resume_call: (function () {
					stopVibro();
					if (mode == 2) updateSteps();
					setSecondsAnim(true);
				}),
				pause_call: (function () {
					stopVibro();
					setSecondsAnim(false);
				}),
			});	
			
			checkConnection(hmFS.SysProGetBool('nsw_checkBT'));
			setEveryHourVibro();
		}

// ---------------------------- AOD --------------------------- \\




//*****************************************************************************************************
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start

            bezel_under = hmUI.createWidget(hmUI.widget.FILL_RECT, {
			  x: 0,
			  y: 0,
			  w: 466,
			  h: 466,
			  radius: 233,
			  color: bezelUnderColor[bezelIndex],
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			bg_fill = hmUI.createWidget(hmUI.widget.FILL_RECT, {
			  x: 20,
			  y: 20,
			  w: 426,
			  h: 426,
			  radius: 203,
			  color: bgColor[colorIndex],
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			text_fill[0] = hmUI.createWidget(hmUI.widget.FILL_RECT, {
			  x: 70,
			  y: 172,
			  w: 326,
			  h: 75,
			  color: textColor[textColorIndex],
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			text_fill[1] = hmUI.createWidget(hmUI.widget.FILL_RECT, {
			  x: 190,
			  y: 385,
			  w: 87,
			  h: 30,
			  color: textColor[textColorIndex],
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			text_fill[2] = hmUI.createWidget(hmUI.widget.FILL_RECT, {
			  x: 190,
			  y: 48,
			  w: 87,
			  h: 68,
			  color: textColor[textColorIndex],
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

            normal_background_bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 110,
              y: 135,
              font_array: ["digTemp_0.png","digTemp_1.png","digTemp_2.png","digTemp_3.png","digTemp_4.png","digTemp_5.png","digTemp_6.png","digTemp_7.png","digTemp_8.png","digTemp_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'digTemp_deg.png',
              unit_tc: 'digTemp_deg.png',
              unit_en: 'digTemp_deg.png',
              negative_image: 'digTemp_minus.png',
              invalid_image: 'digTemp_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			autoToggleWeatherIcons();
            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 72,
              y: 125,
              image_array: weather_icons,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 135,
              font_array: ["digTemp_0.png","digTemp_1.png","digTemp_2.png","digTemp_3.png","digTemp_4.png","digTemp_5.png","digTemp_6.png","digTemp_7.png","digTemp_8.png","digTemp_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'digTemp_percent.png',
              unit_tc: 'digTemp_percent.png',
              unit_en: 'digTemp_percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 54,
              y: 238,
              w: 360,
              h: 30,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              color: textColor[textColorIndex],
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 74,
              y: 239,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 220,
              y: 145,
              src: `status_clock_${textColorIndex}.png`,
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			second_circle_scale = hmUI.createWidget(hmUI.widget.ARC, {
			  x: 0,
			  y: 0,
			  w: 466,
			  h: 466,
			  start_angle: -87,
			  end_angle: 273,
			  color: 0xFF000000,
			  line_width: 13,
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			updateSeconds();

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 192,
              day_startY: 77,
              day_sc_array: ["digDate_0.png","digDate_1.png","digDate_2.png","digDate_3.png","digDate_4.png","digDate_5.png","digDate_6.png","digDate_7.png","digDate_8.png","digDate_9.png"],
              day_tc_array: ["digDate_0.png","digDate_1.png","digDate_2.png","digDate_3.png","digDate_4.png","digDate_5.png","digDate_6.png","digDate_7.png","digDate_8.png","digDate_9.png"],
              day_en_array: ["digDate_0.png","digDate_1.png","digDate_2.png","digDate_3.png","digDate_4.png","digDate_5.png","digDate_6.png","digDate_7.png","digDate_8.png","digDate_9.png"],
              day_zero: 1,
              day_space: -1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 116,
              month_startY: 88,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 294,
              y: 93,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 278,
              font_array: ["digAct_0.png","digAct_1.png","digAct_2.png","digAct_3.png","digAct_4.png","digAct_5.png","digAct_6.png","digAct_7.png","digAct_8.png","digAct_9.png"],
              padding: false,
              h_space: -1,
              invalid_image: 'digAct_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 278,
              font_array: ["digAct_0.png","digAct_1.png","digAct_2.png","digAct_3.png","digAct_4.png","digAct_5.png","digAct_6.png","digAct_7.png","digAct_8.png","digAct_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 62,
              y: 278,
              font_array: ["digAct_0.png","digAct_1.png","digAct_2.png","digAct_3.png","digAct_4.png","digAct_5.png","digAct_6.png","digAct_7.png","digAct_8.png","digAct_9.png"],
              padding: false,
              h_space: 2,
              dot_image: 'digAct_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            bezel = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: `bezel_${bezelIndex}.png`,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
/*
            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 161,
              y: 337,
              font_array: ["digStep_0.png","digStep_1.png","digStep_2.png","digStep_3.png","digStep_4.png","digStep_5.png","digStep_6.png","digStep_7.png","digStep_8.png","digStep_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
*/
		
            steps_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 331,
              w: 466,
              h: 50,
              text_size: 50,
              char_space: 0,
              line_space: 0,
              color: textColor[textColorIndex],
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            step.addEventListener(hmSensor.event.CHANGE, function() {
              updateSteps();
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 73,
              hour_startY: 177,
              hour_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_align: hmUI.align.LEFT,

              minute_startX: 253,
              minute_startY: 177,
              minute_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            dots = hmUI.createWidget(hmUI.widget.IMG, {
              x: 226,
              y: 192,
              src: 'dots.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


			//смена цвета
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 393,
              y: 171,
              w: 80,
              h: 100,
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				changeColor();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			//смена цвета безеля
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 171,
              w: 70,
              h: 100,
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				getClick();
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			//смена цвета цифр
			settings_btn = hmUI.createWidget(hmUI.widget.IMG, {
              x: 322,
              y: 19,
              w: 100,
              h: 80,
			  src: 'blank.png',
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			settings_btn.addEventListener(hmUI.event.CLICK_DOWN, function () {
				if(longPress_Timer) timer.stopTimer(longPress_Timer);
				longPress_Timer = timer.createTimer(longPressDelay, 0, openSettingsScreen, {});
			});
			settings_btn.addEventListener(hmUI.event.CLICK_UP, function () {
				if(longPress_Timer) timer.stopTimer(longPress_Timer);
				changeTextColor();
			});


			//запуск приложения по нажатию на часы
			hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 86,
			  y: 172,
			  w: 122,
			  h: 80,
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				showAppScreen(tapH);
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

			//запуск приложения по нажатию на минуты
			hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 257,
			  y: 172,
			  w: 122,
			  h: 80,
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				showAppScreen(tapM);
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 191,
              y: 126,
              w: 85,
              h: 50,
              src: 'blank.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 74,
              y: 99,
              w: 100,
              h: 70,
              src: 'blank.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 313,
              y: 277,
              w: 100,
              h: 100,
              src: 'blank.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			// календарь
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 183,
              y: 24,
              w: 100,
              h: 100,
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 183,
              y: 258,
              w: 100,
              h: 70,
              src: 'blank.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 170,
              y: 336,
              w: 130,
              h: 100,
              src: 'blank.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


			const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
			  resume_call: (function () {
				updateCityName();
				updateSteps();
				autoToggleWeatherIcons();
				normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, true);
				setTimeout(() => {
					dotsVisible = true;
					showDots();
					setSecondsAnim(true);
				}, 1000 - curTime.utc % 1000);
							
			  }),
			  pause_call: (function () {
					setSecondsAnim(false);
					if (randomColor) setRandomColors();
			  }),
			});

			createSettingsScreen();
			createTapsScreen();

                //dynamic modify end
            },
            onInit() {
				loadSettings();
                n.log("index page.js on init invoke");
            },
            build() {
				if (hmSetting.getScreenType() == hmSetting.screen_type.AOD){
					makeAOD();
				} else {
					this.init_view();
				}
            },
            onDestroy() {
				vibrate && vibrate.stop();
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
